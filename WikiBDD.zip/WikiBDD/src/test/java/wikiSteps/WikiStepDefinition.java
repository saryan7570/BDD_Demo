package wikiSteps;

import static org.testng.Assert.assertEquals;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class WikiStepDefinition {
	
	private WebDriver webDriver;

	@Given("^user is on home page$")
	public void user_is_on_home_page() throws InterruptedException {
		File file = new File(
				"C:\\Users\\nsingh68\\Desktop\\Module 4\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
		webDriver = new ChromeDriver();
		webDriver.navigate().to("https://www.wikipedia.org/");
		Thread.sleep(2000);
	}
	
	@When("^user enters a search keyword$")
	public void user_enters_a_search_keyword() throws Throwable {
		webDriver.findElement(By.id("searchInput")).sendKeys("Anonymous");
		Thread.sleep(2000);														// Not mandatory
	}

	@When("^user clicks on search button$")
	public void user_clicks_on_search_button() throws Throwable {
		WebElement webElement = webDriver.findElement(By.id("searchInput"));
		webElement.submit();
		Thread.sleep(2000);
	}

	@Then("^it open corresponding wiki page$")
	public void it_open_corresponding_wiki_page() throws Throwable {
		String expectedTitle = webDriver.getTitle();
		assertEquals(expectedTitle, "Anonymous - Wikipedia");
	}
}