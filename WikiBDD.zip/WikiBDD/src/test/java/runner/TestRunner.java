package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "C:\\Users\\nsingh68\\Desktop\\Module 4\\WikiBDD\\src\\test\\java\\features", dryRun = false, glue = "wikiSteps")
public class TestRunner {

}